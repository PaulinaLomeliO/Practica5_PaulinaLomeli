#include <stdio.h>
#include "MKL25Z4.h"

void pinMode(unsigned char ubPort, unsigned int ubPin,unsigned char ubMode);
void digitalWrite( unsigned char ubPort,unsigned int ubPin, unsigned char ubMode);

void led (void){
}

void pinMode(unsigned char ubPort, unsigned int ubPin,unsigned char ubMode){
	SIM->SCGC5= 1<<9; //Activa la señal de reloj del puerto A
	SIM->SCGC5= 1<<10; //Activa la señal de reloj del puerto B
	SIM->SCGC5= 1<<11; //Activa la señal de reloj del puerto C
	SIM->SCGC5= 1<<12; //Activa la señal de reloj del puerto D
	SIM->SCGC5= 1<<13; //Activa la señal de reloj del puerto E

	switch(ubPort){
	case 'A':
		PORTA->PCR[ubPin]= 1<<8; //El pin seleccionado del puerto A se coloca como un GPIO
		GPIOA->PDDR=ubMode<<ubPin; //Si se coloca un 1 en el pin seleccionado se configura como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'B':
		PORTB->PCR[ubPin]= 1<<8;  //El pin seleccionado del puerto B se coloca como un GPIO
		GPIOB->PDDR=ubMode<<ubPin;  //Si se coloca un 1 en el pin seleccionado se configura como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'C':
		PORTC->PCR[ubPin]= 1<<8;  //El pin seleccionado del puerto C se coloca como un GPIO
		GPIOC->PDDR=ubMode<<ubPin; //Si se coloca un 1 en el pin seleccionado se configura como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'D':
		PORTD->PCR[ubPin]= 1<<8;  //El pin seleccionado del puerto D se coloca como un GPIO
		GPIOD->PDDR=ubMode<<ubPin;  //Si se coloca un 1 en el pin seleccionado se configura como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'E':
		PORTE->PCR[ubPin= 1<<8;  //El pin seleccionado del puerto E se coloca como un GPIO
		GPIOE->PDDR=ubMode<<ubPin;  //Si se coloca un 1 en el pin seleccionado se configura como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	}
}

void digitalWrite(unsigned char ubPort,unsigned int ubPin, unsigned char ubMode){
	if(ubMode==0){
	switch(ubPort){
		case 'A':	  //Se coloca un 1 en la posición del pin
			GPIOA->PCOR=1<<ubPin; // Si se mandó un 0 se prende el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'B':
			GPIOB->PCOR=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'C':
			GPIOC->PCOR=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'D':
			GPIOD->PCOR=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
			break;
		case 'E':
			GPIOE->PCOR=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
			break;
	}
	}else{
	switch(ubPort){
		case 'A':
			GPIOA->PTOR=1<<ubPin; //invierte (PTOR= Port Toggle Output Register)
		break;
		case 'B':
			GPIOB->PTOR=1<<ubPin; // invierte (PTOR= Port Toggle Output Register)
		break;
		case 'C':
			GPIOC->PTOR=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'D':
			GPIOD->PTOR=1<<ubPin; //invierte (PTOR= Port Toggle Output Register)
			break;
		case 'E':
			GPIOE->PTOR=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
			break;
	}
	}
}

